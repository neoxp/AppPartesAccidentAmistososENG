//
//  MyTextDocument.m
//  bolduoptic
//
//  Created by HackerWebMaster on 27/7/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
// StringNovaMatricula

#import "MyTextDocument.h"
#import "ViewController.h"
#import "ViewController2.h"
#import <AudioToolbox/AudioServices.h>


@implementation MyTextDocument

@synthesize StringCompanyia = _StringCompanyia;
@synthesize StringMatricula = _StringMatricula;
@synthesize StringDNI = _StringDNI;
@synthesize StringNPoliza = _StringNPoliza;
@synthesize StringConductor = _StringConductor;
@synthesize StringDNIConductor = _StringDNIConductor;
@synthesize StringFirmaDigital = _StringFirmaDigital;
@synthesize StringNovaMatricula = _StringNovaMatricula;


@synthesize StringFirmaDigitalSegonaPersona = _StringFirmaDigitalSegonaPersona;
@synthesize delegate = _delegate;



- (BOOL)loadFromContents:(id)contents ofType:(NSString *)typeName error:(NSError **)outError
{
    NSLog(@"UIDocument: loadFromContents: state = %d, typeName=%@", self.StringCompanyia,
          self.StringMatricula,self.StringDNI,self.StringNPoliza,self.StringConductor,self.StringDNIConductor,
          self.StringFirmaDigital,self.StringFirmaDigitalSegonaPersona,self.StringNovaMatricula, typeName);
    
    if ([contents length] > 0) {
        self.StringCompanyia = [[NSString alloc] initWithBytes:[contents bytes] length:[contents length] encoding:NSUTF8StringEncoding];
    }
    else {
        self.StringCompanyia = @"";
    }
    
    if ([contents length] > 0) {
        self.StringMatricula = [[NSString alloc] initWithBytes:[contents bytes] length:[contents length] encoding:NSUTF8StringEncoding];
    }
    if (StringMatricula==delegate) {
        self.StringMatricula = @"";
    }
    
    else if (StringNovaMatricula != StringMatricula==NSMetadataQueryUbiquitousDocumentsScope,"SUCCEEDED") {
        self.StringNovaMatricula= @"";
        
    }

    
    if ([contents length] > 0) {
        self.StringDNI = [[NSString alloc] initWithBytes:[contents bytes] length:[contents length] encoding:NSUTF8StringEncoding];
    }
    else {
        self.StringDNI = @"";
    }
    
    if ([contents length] > 0) {
        self.StringNPoliza = [[NSString alloc] initWithBytes:[contents bytes] length:[contents length] encoding:NSUTF8StringEncoding];
    }
    else {
        self.StringNPoliza = @"";
    }
    
    if ([contents length] > 0) {
        self.StringConductor = [[NSString alloc] initWithBytes:[contents bytes] length:[contents length] encoding:NSUTF8StringEncoding];
    }
    else {
        self.StringConductor = @"";
    }
    
    if ([contents length] > 0) {
        self.StringDNIConductor = [[NSString alloc] initWithBytes:[contents bytes] length:[contents length] encoding:NSUTF8StringEncoding];
    }
    else {
        self.StringDNIConductor = @"";
    }
    
    if ([contents length] > 0) {
        self.StringFirmaDigital = [[NSString alloc] initWithBytes:[contents bytes] length:[contents length] encoding:NSUTF8StringEncoding];
    }
    else {
        self.StringFirmaDigital = @"";
    }
    
    if ([contents length] > 0) {
        self.StringFirmaDigitalSegonaPersona = [[NSString alloc] initWithBytes:[contents bytes] length:[contents length] encoding:NSUTF8StringEncoding];
    }
    else {
        self.StringFirmaDigitalSegonaPersona = @"";
    }
    
    NSLog(@"UIDocument: Loaded the following text from the cloud: %@", self.StringCompanyia,
          self.StringMatricula,self.StringNovaMatricula,self.StringDNI,self.StringNPoliza,self.StringConductor,self.StringDNIConductor,self.StringFirmaDigital,self.StringFirmaDigitalSegonaPersona);
    
    
  
    if ([_delegate respondsToSelector:@selector(noteDocumentContentsUpdated:)]) {
        [_delegate descriptionWithLocale:delegate];
    }
    
    return YES;
    
}


-(id)contentsForType:(NSString *)typeName error:(NSError **)outError
{
    if ([self.StringCompanyia length] == 0) {
        self.StringCompanyia = @"New Note";
    }
    
    if ([self.StringMatricula length] == 7) {
        self.StringMatricula = @"New Note";
    }
    
    if ([self.StringNovaMatricula length] == 7) {
        self.StringNovaMatricula = @"New Note";
    }
    
    if ([self.StringDNI length] == 0) {
        self.StringDNI = @"New Note";
    }
    if ([self.StringNPoliza length] == 0) {
        self.StringNPoliza = @"New Note";
    }
    if ([self.StringConductor length] == 0) {
        self.StringConductor = @"New Note";
    }
    if ([self.StringDNIConductor length] == 0) {
        self.StringDNIConductor = @"New Note";
    }
    if ([self.StringFirmaDigital length] == 0) {
        self.StringFirmaDigital = @"New Note";
    }
    
    if ([self.StringFirmaDigitalSegonaPersona length] == 0) {
        self.StringFirmaDigitalSegonaPersona = @"New Note";
    }
    NSLog(@"UIDocument: Will save the following text in the cloud: %@", self.StringCompanyia,
          self.StringMatricula,self.StringNovaMatricula,self.StringDNI,self.StringNPoliza,self.StringConductor,self.StringDNIConductor,self.StringFirmaDigital,self.StringFirmaDigitalSegonaPersona);
    
    return [NSData dataWithBytes:[self.StringCompanyia UTF8String] length:[self.StringCompanyia length]];
    return [NSData dataWithBytes:[self.StringMatricula UTF8String] length:[self.StringMatricula length]];
     return [NSData dataWithBytes:[self.StringNovaMatricula UTF8String] length:[self.StringNovaMatricula length]];
    return [NSData dataWithBytes:[self.StringDNI UTF8String] length:[self.StringDNI length]];
    return [NSData dataWithBytes:[self.StringNPoliza UTF8String] length:[self.StringNPoliza length]];
    return [NSData dataWithBytes:[self.StringConductor UTF8String] length:[self.StringConductor length]];
    return [NSData dataWithBytes:[self.StringDNIConductor UTF8String] length:[self.StringDNIConductor length]];
    return [NSData dataWithBytes:[self.StringFirmaDigital UTF8String] length:[self.StringFirmaDigital length]];
    return [NSData dataWithBytes:[self.StringFirmaDigitalSegonaPersona UTF8String] length:[self.StringFirmaDigitalSegonaPersona length]];
}
@end
