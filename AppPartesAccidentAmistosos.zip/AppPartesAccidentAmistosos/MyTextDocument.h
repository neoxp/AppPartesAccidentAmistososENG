//
//  MyTextDocument.h
//  bolduoptic
//
//  Created by HackerWebMaster on 27/7/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "ViewController2.h"
#import <AudioToolbox/AudioServices.h>

#import "ParteB.h"
#import "ParteB+CoreDataProperties.h"
#import "DatosID.h"
#import "DatosID.h"
#import "ParteB.h"
#import "ParteA.h"
#import "ParteA+CoreDataProperties.h"
#import "ParteA.h"
#import "DatosID.h"

@class ViewController, ViewController2;

@interface MyTextDocument : UIDocumentInteractionController{
    
    NSString *StringCompanyia;
    NSString *StringMatricula;
    NSString *StringNovaMatricula;
    
    NSString *StringDNI;
    NSString *StringNPoliza;
    NSString *StringConductor;
    NSString *StringDNIConductor;
    NSString *StringFirmaDigital;
    NSString *StringFirmaDigitalSegonaPersona;
    id delegate;
    
}

@property (nonatomic, retain) NSString *StringCompanyia;
@property (nonatomic, retain) NSString *StringMatricula;
@property (nonatomic, retain) NSString *StringDNI;
@property (nonatomic, retain) NSString *StringNPoliza;
@property (nonatomic, retain) NSString *StringConductor;
@property (nonatomic, retain) NSString *StringDNIConductor;
@property (nonatomic, retain) NSString *StringFirmaDigital;
@property (nonatomic, retain) NSString *StringFirmaDigitalSegonaPersona;

@property (nonatomic, retain) NSString *StringNovaMatricula;

@property (nonatomic, assign) id delegate;

@end
