//
//  TableViewController.h
//  AppPartesAccidentAmistosos
//
//  Created by HackerWebMaster on 9/8/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController

@end
