//
//  changePictureProtocol.h
//  AppPartesAccidentAmistosos
//
//  Created by HackerWebMaster on 8/8/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol changePictureProtocol <NSObject>
-(void)loadNewScreen:(UIViewController *)controller;
@end


@interface changePictureProtocol : NSObject

@property (nonatomic, retain) id<changePictureProtocol> delegate;
@end
