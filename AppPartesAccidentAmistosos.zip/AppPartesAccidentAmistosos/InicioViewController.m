//
//  InicioViewController.m
//  AppPartesAccidentAmistosos
//
//  Created by Hackermaster on 27/04/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import "InicioViewController.h"
#import "UIImage+animatedGIF.h"

@interface InicioViewController ()

@end

@implementation InicioViewController
@synthesize dataImageView;
@synthesize urlImageView;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"MiLogo" withExtension:@"gif"];

    
    url = [[NSBundle mainBundle] URLForResource:@"MiLogo" withExtension:@"gif"];
 
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return interfaceOrientation == UIInterfaceOrientationPortrait;
}

@end