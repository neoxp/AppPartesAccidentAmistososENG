//
//  ParteA+CoreDataProperties.h
//  AppPartesAccidentAmistosos
//
//  Created by HackerMaster   on 16/11/16.
//  Copyright © 2016 Emili Marqués Forés. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "ParteA.h"

NS_ASSUME_NONNULL_BEGIN

@interface ParteA (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *novaMatricula;
@property (nullable, nonatomic, retain) NSString *matricula;
@property (nullable, nonatomic, retain) NSString *numeroPoliza;
@property (nullable, nonatomic, retain) NSString *companyia;
@property (nullable, nonatomic, retain) NSString *dni;
@property (nullable, nonatomic, retain) NSString *conductor;
@property (nullable, nonatomic, retain) NSString *firmaconductorA;
@property (nullable, nonatomic, retain) NSNumber *fotosaccident;
@property (nullable, nonatomic, retain) NSString *id;
@property (nullable, nonatomic, retain) DatosID *relationship;

@end

NS_ASSUME_NONNULL_END
