//
//  InicioViewController.h
//  AppPartesAccidentAmistosos
//
//  Created by Hackermaster on 27/04/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InicioViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *dataImageView;
@property (strong, nonatomic) IBOutlet UIImageView *urlImageView;
@property (strong, nonatomic) IBOutlet UIImageView *variableDurationImageView;
@end
