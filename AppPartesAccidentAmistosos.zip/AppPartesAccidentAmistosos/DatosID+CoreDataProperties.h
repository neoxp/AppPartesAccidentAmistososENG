//
//  DatosID+CoreDataProperties.h
//  AppPartesAccidentAmistosos
//
//  Created by HackerMaster   on 16/11/16.
//  Copyright © 2016 Emili Marqués Forés. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "DatosID.h"

NS_ASSUME_NONNULL_BEGIN

@interface DatosID (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *id;
@property (nullable, nonatomic, retain) NSString *companyia;
@property (nullable, nonatomic, retain) NSString *numeroMatricula;
@property (nullable, nonatomic, retain) NSString *dni;
@property (nullable, nonatomic, retain) NSString *numeroPoliza;
@property (nullable, nonatomic, retain) NSManagedObject *relationship;
@property (nullable, nonatomic, retain) ParteB *relationship1;

@end

NS_ASSUME_NONNULL_END
