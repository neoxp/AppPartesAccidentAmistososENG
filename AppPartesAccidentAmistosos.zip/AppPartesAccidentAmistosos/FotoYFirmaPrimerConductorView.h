//
//  FotoYFirmaPrimerConductorView.h
//  AppPartesAccidentAmistosos
//
//  Created by HackerWebMaster on 8/8/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MessageUI/MessageUI.h>
#import <CFNetwork/CFNetwork.h>
#import <Accelerate/Accelerate.h>
#import <sqlite3.h>
#import <sqlite3ext.h>
#import <CoreData/CoreData.h>


@interface FotoYFirmaPrimerConductorView : UIView<UITextFieldDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,MFMailComposeViewControllerDelegate, UIDataSourceModelAssociation,NSMutableCopying,NSXMLParserDelegate>{
    

    NSString *StringFirmaDigital;
    
    UIImageView *imagenView1;
    UIImageView *imagenView2;
    UIButton    *tomarFoto;
    IBOutlet UILabel *cargado;
    
}




@property (weak, nonatomic) IBOutlet UITextField *textFieldFirmaDigital;


@property (nonatomic, copy) NSString *StringFirmaDigital;

@property (nonatomic, retain) IBOutlet UIImageView *imagenView1;

@property (nonatomic, retain) IBOutlet UIImageView *imagenView2;

@property (nonatomic, retain) IBOutlet UIButton *tomarFoto;
@property (weak, nonatomic) IBOutlet UIButton *BtnEnviar;

- (IBAction)tomarFoto:(id)sender;

-(IBAction)EnviarFormulario:(id)sender;

@end
