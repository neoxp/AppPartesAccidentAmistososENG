//
//  DatosID+CoreDataProperties.m
//  AppPartesAccidentAmistosos
//
//  Created by HackerMaster   on 16/11/16.
//  Copyright © 2016 Emili Marqués Forés. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "DatosID+CoreDataProperties.h"

@implementation DatosID (CoreDataProperties)

@dynamic id;
@dynamic companyia;
@dynamic numeroMatricula;
@dynamic dni;
@dynamic numeroPoliza;
@dynamic relationship;
@dynamic relationship1;

@end
