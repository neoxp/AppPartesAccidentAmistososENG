

#import <UIKit/UIKit.h>
#import <iCloud/iCloud.h>

@interface DocumentViewController : UIViewController <UITextViewDelegate, UIViewControllerTransitioningDelegate>

- (IBAction)shareDocument:(id)sender;

@property (weak, nonatomic)  IBOutlet UITextField *textFieldCompanyia;

@property (weak, nonatomic)  IBOutlet UITextField *textFieldMatricula;

@property (weak, nonatomic) IBOutlet UITextField *textFieldDNI;

@property (weak, nonatomic)  IBOutlet UITextField *textFieldNpoliza;

@property (weak, nonatomic)  IBOutlet UITextField *textFieldConductor;

@property (weak, nonatomic) IBOutlet UITextField *textFieldDNIConductor;


@property (weak, nonatomic) IBOutlet UITextField *textFieldFirmaDigital;
@property (weak, nonatomic) IBOutlet UITextField *textFieldFirmaDigitalSegonaPersona;



@property (strong, nonatomic) NSString *fileText;
@property (strong, nonatomic) NSString *fileName;
@property (nonatomic, retain) NSString *StringNovaMatricula;
@property (strong, nonatomic) NSString *fileLink;
@property (strong, nonatomic) NSString *fileExpirationDate;


@end
